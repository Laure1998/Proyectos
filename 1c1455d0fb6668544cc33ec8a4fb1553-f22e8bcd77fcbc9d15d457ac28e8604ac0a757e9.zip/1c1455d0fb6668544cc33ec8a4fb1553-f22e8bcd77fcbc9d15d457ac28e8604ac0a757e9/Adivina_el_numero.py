from random import *
intentos= 0
estimado= 0
numero_secreto= randint(1,101)
nombre = input("Dime tu nombre: ")
print(f"Hola {nombre}! pensé en un número entre el 1 y el 100, ¿podrás adivinar cual es?\n tenes 8 intentos para adivinarlo")
while intentos < 8:
    estimado= int(input("¿Cuál es el número?: "))
    intentos +=1
    if estimado not in range(1,101):
        print("No se encuentra en el rango que va de 1 a 100")
    elif estimado<numero_secreto:
        print("Mi número es mas alto")
    elif estimado > numero_secreto:
        print("Mi número es mas bajo")
    else:
        print(f"Felicitaciones {nombre}! adivinaste el número en {intentos} intentos")
        break
if estimado !=numero_secreto:
    print(f"Se te agotaron los intetos, el número secreto era {numero_secreto}")



